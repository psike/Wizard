# -*- coding: utf-8 -*-
#------------------------------------------------------------
# The Atraf Addon by Abeksis | www.abeksis.com
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Atraf 2016 © abeksis
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.atraf'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PL5CC64BF055E4F1DF"
YOUTUBE_CHANNEL_ID_2 = "PLECF0304409C6E326"
YOUTUBE_CHANNEL_ID_3 = "PLDA238A7420221703"
YOUTUBE_CHANNEL_ID_4 = "PL76tprfc11flz1_awCcqXMU54HAKmU9hQ"



# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="השירים החמים",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQcurfadQs9Xd8zuzQmhpl70CYycSPzCYZ3yPCCzBy5v78cyh7sAw",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="אוסף מזרחית שקטים - אוסף ראשון",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0LXZgh73QieieP9B5SRF7UEFi6uq5jRFYM1WutheqxQLq0OOZ",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="אוסף מזרחית שקטים - אוסף שני",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRr-5e3YC-VCWIm47Wi8533LcbXbqwssxn479VD4uu8JffYVGg6",
        folder=True )        
              
    plugintools.add_item( 
        #action="", 
        title="השירים החמים 2",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjydjzyevAnT9JybCJfl_WBYPa8uG-n3xGRxRiAcIC0VXZkPQz4A",
        folder=True )         
                                                
run()
