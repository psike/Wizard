from xbmc import executebuiltin, getInfoLabel, getCondVisibility, translatePath
from sys import listitem
from urllib import quote

def main():
	if not hasattr(sys, 'listitem'):
		print "*** TheWiz Wall Context: Abort"
		return 
	
	path = getInfoLabel('ListItem.FileNameAndPath')
	txt = open(translatePath(path))
	file_args = txt.read().replace("plugin://plugin.video.thewiz.wall/?","")

	print '*** TheWiz Wall Context: wall=%s")' % (quote(file_args))
	executebuiltin('RunScript(plugin.video.thewiz.wall,"1","?action=player&%s")' % (file_args))

if __name__ == '__main__':
    main()
